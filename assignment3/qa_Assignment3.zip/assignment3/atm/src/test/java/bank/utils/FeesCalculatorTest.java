package bank.utils;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

// Use of Parameterized helps in this case, since multiple runs of same test are required
class FeesCalculatorTest {
	FeesCalculator calculator = new FeesCalculator();

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

/*

BLACKBOX TESTING

	@ParameterizedTest
	@CsvSource({
			"0, 0, 0, true, 1",
			"0, 1, 1, true, 7",
			"0.1, 100, 1000, true, 2",
			"0.1, 100, 999, true, 6",
			"0, 100, -1, true, 3",
			"0, 0, 0, false, 6",
			"0.002, 1, 1, false, 1",
			"0.2, 100, 999, false, 7",
			"0.2, 100, 998, false, 5",
			"0.1, 100, 1000, false, 6",
			"0.1, 100, 1001, false, 1",
			"0.1, 100, 9999, false, 7",
			"0.1, 100, 10000, false, 5",
			"0, 100, 10001, false, 6",
			"0, 100, 10002, false, 1",
			"0, 100, 99999, false, 7",
			"0, 100, 100000, false, 5",
			"0, 100, -1, false, 3"
	})
	void withdrawalTest(double result, double amount, double accountBalance, boolean student, int day) {
		assertEquals(result, calculator.calculateWithdrawalFee(amount, accountBalance, student, day));		//pass
		//assertEquals(0.01, calculator.calculateWithdrawalFee(200, 1000, false, 0));	//fail
	}

	@ParameterizedTest
	@CsvSource({
			"1.5, 150, 1500, true",
			"0.75, 150, 500, true",
			"0.25, 50, 5500, true",
			"0, 50, 4500, true",
			"0, 1, 50, true",
			"5.5, 550, 5500, false",
			"2.75, 550, 4500, false",
			"2.25, 450, 15000, false",
			"0, 450, 5000, false",
			"0, 1, 50, false"
	})
	void depositTest(double result, double amount, double accountBalance, boolean student) {
		assertEquals(result, calculator.calculateDepositInterest(amount, accountBalance, student));
	}

	@Test
	void transferTest() {
		assertEquals(0.05, calculator.calculateTransferFee(50, 500, 500, true));		//fail
		assertEquals(0.025, calculator.calculateTransferFee(50, 500, 1500, true));	//fail
		assertEquals(0.25, calculator.calculateTransferFee(50, 1500, 500, true));		//fail
		assertEquals(0.13, calculator.calculateTransferFee(50, 1500, 1500, true));	//fail
		assertEquals(0.075, calculator.calculateTransferFee(150, 500, 500, true));	//fail
		assertEquals(0.037, calculator.calculateTransferFee(150, 500, 1500, true));	//fail
		assertEquals(0.38, calculator.calculateTransferFee(150, 1500, 500, true));	//fail
		assertEquals(0.19, calculator.calculateTransferFee(150, 1500, 1500, true));	//fail
		assertEquals(0.1, calculator.calculateTransferFee(50, 500, 500, false));		//fail
		assertEquals(0.05, calculator.calculateTransferFee(50, 500, 1500, false));	//fail
		assertEquals(0.5, calculator.calculateTransferFee(50, 1500, 500, false));		//fail
		assertEquals(0.25, calculator.calculateTransferFee(50, 1500, 1500, false));	//fail
		assertEquals(0.15, calculator.calculateTransferFee(150, 500, 500, false));	//fail
		assertEquals(0.075, calculator.calculateTransferFee(150, 500, 1500, false));	//fail
		assertEquals(0.75, calculator.calculateTransferFee(150, 1500, 500, false));	//fail
		assertEquals(0.38, calculator.calculateTransferFee(150, 1500, 1500, false));	//fail
	}
*/
	@ParameterizedTest
	@CsvSource({
			"0.05, 50, 500, 500, true",
			"0.025, 50, 500, 1500, true",
			"0.25, 50, 1500, 500, true",
			"0.125, 50, 1500, 1500, true",
			"0.075, 150, 500, 500, true",
			"0.0375, 150, 500, 1500, true",
			"0.375, 150, 1500, 500, true",
			"0.1875, 150, 1500, 1500, true",
			"0.1, 50, 500, 500, false",
			"0.05, 50, 500, 1500, false",
			"0.5, 50, 1500, 500, false",
			"0.25, 50, 1500, 1500, false",
			"0.15, 150, 500, 500, false",
			"0.075, 150, 500, 1500, false",
			"0.75, 150, 1500, 500, false",
			"0.375, 150, 1500, 1500, false"
	})
	void transferTest(double result, double amount, double senderBalance, double receiverBalance, boolean student) {
		assertEquals(result, calculator.calculateTransferFee(amount, senderBalance, receiverBalance, student));
	}

}
