package bank.transactions;

import bank.db.DBHandler;
import bank.exceptions.CardNotFoundException;
import bank.exceptions.UnsuccessfulBalanceUpdate;
import bank.exceptions.UserNotFoundException;
import bank.transactions.utils.AccountType;
import bank.transactions.utils.TransactionData;
import bank.transactions.utils.TransactionResult;
import bank.transactions.utils.TransactionType;
import bank.utils.FeesCalculator;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class BankTransferTest {
    private static final String STUDENT_CARD_NUMBER = "4000000000000000";
    private static final String NON_STUDENT_CARD_NUMBER = "4000000000000001";

    private static final String STUDENT_CARD_OWNER = "ktsiounis";
    private static final String NON_STUDENT_CARD_OWNER = "khu";

    private static final char[] STUDENT_PIN = "5555".toCharArray();
    private static final char[] NON_STUDENT_PIN = "4444".toCharArray();

    public AccountType[] accounts = {AccountType.Chequing, AccountType.Savings};

    public FeesCalculator mockFeesCalculator;
    public DBHandler mockDbHandler;

    public FeesCalculator feesCalculator;
    public DBHandler dbHandler;


    private static Stream<Arguments> testParams() {
        return Stream.of(
                Arguments.of(0.05, 50.00, 500.00, 500.00, true),
                Arguments.of(0.025, 50.00, 500.00, 1500.00, true),
                Arguments.of(0.25, 50.00, 1500.00, 500.00, true),
                Arguments.of(0.125, 50.00, 1500.00, 1500.00, true),
                Arguments.of(0.075, 150.00, 500.00, 500.00, true),
                Arguments.of(0.0375, 150.00, 500.00, 1500.00, true),
                Arguments.of(0.375, 150.00, 15000.00, 500.00, true),
                Arguments.of(0.1875, 150.00, 1500.00, 1500.00, true),
                Arguments.of(0.1, 50.00, 500.00, 500.00, false),
                Arguments.of(0.05, 50.00, 500.00, 1500.00, false),
                Arguments.of(0.5, 50.00, 1500.00, 500.00, false),
                Arguments.of(0.25, 50.00, 1500.00, 1500.00, false),
                Arguments.of(0.15, 150.00, 500.00, 500.00, false),
                Arguments.of(0.075, 150.00, 500.00, 1500.00, false),
                Arguments.of(0.75, 150.00, 1500.00, 500.00, false),
                Arguments.of(0.375, 150.00, 1500.00, 1500.00, false)
        );
    }

    @BeforeAll
    void setUp() throws CardNotFoundException, UserNotFoundException, UnsuccessfulBalanceUpdate {
        mockFeesCalculator = mock(FeesCalculator.class);
        mockDbHandler = mock(DBHandler.class);

        feesCalculator = new FeesCalculator();
        dbHandler = new DBHandler();
    }
    @ParameterizedTest
    @MethodSource("testParams")
    void bankTransferTest1(double result, double amount, double senderBalance, double receiverBalance, boolean student) throws Exception{
        when(mockDbHandler.getCardOwner(STUDENT_CARD_NUMBER)).thenReturn(STUDENT_CARD_OWNER);
        when(mockDbHandler.getBalance(STUDENT_CARD_OWNER, accounts[0])).thenReturn(senderBalance);
        when(mockDbHandler.getBalance(STUDENT_CARD_OWNER, accounts[1])).thenReturn(receiverBalance);
        when(mockDbHandler.isStudent(STUDENT_CARD_OWNER)).thenReturn(student);
        when(mockFeesCalculator.calculateTransferFee(amount, senderBalance,receiverBalance, student)).thenReturn(result);

        BankTransfer bankTransfer = new BankTransfer(mockFeesCalculator, mockDbHandler);
        TransactionData transactionData = new TransactionData(STUDENT_CARD_NUMBER, STUDENT_PIN, TransactionType.Transfer, accounts, amount);
        TransactionResult transactionResult = bankTransfer.perform(transactionData);

        assertEquals(result, transactionResult.getFees());
    }
    @ParameterizedTest
    @MethodSource("testParams")
    void bankTransferTest2(double result, double amount,double senderBalance, double receiverBalance, boolean student) throws Exception {
        when(mockDbHandler.getCardOwner(STUDENT_CARD_NUMBER)).thenReturn(STUDENT_CARD_OWNER);
        when(mockDbHandler.getBalance(STUDENT_CARD_OWNER, AccountType.Chequing)).thenReturn(senderBalance);
        when(mockDbHandler.getBalance(STUDENT_CARD_OWNER, AccountType.Savings)).thenReturn(receiverBalance);
        when(mockDbHandler.isStudent(STUDENT_CARD_OWNER)).thenReturn(student);

        BankTransfer bankTransfer = new BankTransfer(feesCalculator, mockDbHandler);
        TransactionData transactionData = new TransactionData(STUDENT_CARD_NUMBER, STUDENT_PIN, TransactionType.Transfer, accounts, amount);
        TransactionResult transactionResult = bankTransfer.perform(transactionData);

        assertEquals(result, transactionResult.getFees());
    }

    @ParameterizedTest
    @MethodSource("testParams")
    void bankTransferTest3(double result, double amount, double senderBalance, double receiverBalance, boolean student) throws Exception {
        String username = student ? STUDENT_CARD_OWNER : NON_STUDENT_CARD_OWNER;
        String cardNum = student ? STUDENT_CARD_NUMBER : NON_STUDENT_CARD_NUMBER;
        char[] pin = student ? STUDENT_PIN : NON_STUDENT_PIN;

        dbHandler.setBalance(username, AccountType.Chequing, senderBalance);
        dbHandler.setBalance(username, AccountType.Savings, receiverBalance);

        BankTransfer bankTransfer = new BankTransfer(feesCalculator, dbHandler);
        TransactionData transactionData = new TransactionData(cardNum, pin, TransactionType.Transfer, accounts, amount);
        TransactionResult transactionResult = bankTransfer.perform(transactionData);

        assertEquals(result, transactionResult.getFees());
    }

}