package bank.transactions;

import bank.db.DBHandler;
import bank.transactions.utils.AccountType;
import bank.transactions.utils.TransactionData;
import bank.transactions.utils.TransactionResult;
import bank.transactions.utils.TransactionType;
import bank.utils.FeesCalculator;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class BankDepositTest {
    private static final String STUDENT_CARD_NUMBER = "4000000000000000";
    private static final String STUDENT_CARD_OWNER = "ktsiounis";
    private static final String NON_STUDENT_CARD_NUMBER = "4000000000000001";
    private static final String NON_STUDENT_CARD_OWNER = "khu";
    private static final char[] STUDENT_PIN = "5555".toCharArray();
    private static final char[] NON_STUDENT_PIN = "4444".toCharArray();
    public AccountType[] accounts = {AccountType.Chequing, AccountType.Savings};

    public FeesCalculator mockFeesCalculator;
    public DBHandler mockDbHandler;

    public FeesCalculator feesCalculator;
    public DBHandler dbHandler;

    private static Stream<Arguments> testParams() {
        return Stream.of(
                Arguments.of(1.5, 150.00, 1500.00, true),
                Arguments.of(0.75, 150.00, 500.00, true),
                Arguments.of(0.25, 50.00, 5500.00, true),
                Arguments.of(0.0, 50.00, 4500.00, true),
                Arguments.of(5.5, 550.00, 5500.00, false),
                Arguments.of(2.75, 550.00, 4500.00, false),
                Arguments.of(2.25, 450.00, 15000.00, false),
                Arguments.of(0.0, 450.00, 5000.00, false)
        );
    }

    @BeforeAll
    void setUp(){
        mockFeesCalculator = mock(FeesCalculator.class);
        mockDbHandler = mock(DBHandler.class);

        feesCalculator = new FeesCalculator();
        dbHandler = new DBHandler();
    }

    // TEST FOR 2 STUBS
    @ParameterizedTest
    @MethodSource("testParams")
    void bankDepositTest1(double result, double amount, double accountBalance, boolean student) throws Exception {
        String username = student ? STUDENT_CARD_OWNER : NON_STUDENT_CARD_OWNER;
        String cardNum = student ? STUDENT_CARD_NUMBER : NON_STUDENT_CARD_NUMBER;
        char[] pin = student ? STUDENT_PIN : NON_STUDENT_PIN;

        when(mockDbHandler.getCardOwner(cardNum)).thenReturn(username);
        when(mockDbHandler.getBalance(username, AccountType.Chequing)).thenReturn(accountBalance);
        when(mockDbHandler.isStudent(username)).thenReturn(student);
        when(mockFeesCalculator.calculateDepositInterest(amount, accountBalance, student)).thenReturn(result);

        BankDeposit bankDeposit = new BankDeposit(mockFeesCalculator, mockDbHandler);
        TransactionData transactionData = new TransactionData(cardNum, pin, TransactionType.Deposit, accounts, amount);
        TransactionResult transactionResult = bankDeposit.perform(transactionData);

        assertEquals(result, transactionResult.getFees());
    }

    // TEST FOR 1 STUB
    @ParameterizedTest
    @MethodSource("testParams")
    void bankDepositTest2(double result, double amount, double accountBalance, boolean student) throws Exception {
        String username = student ? STUDENT_CARD_OWNER : NON_STUDENT_CARD_OWNER;
        String cardNum = student ? STUDENT_CARD_NUMBER : NON_STUDENT_CARD_NUMBER;
        char[] pin = student ? STUDENT_PIN : NON_STUDENT_PIN;

        when(mockDbHandler.getCardOwner(cardNum)).thenReturn(username);
        when(mockDbHandler.getBalance(username, AccountType.Chequing)).thenReturn(accountBalance);
        when(mockDbHandler.isStudent(username)).thenReturn(student);

        BankDeposit bankDeposit = new BankDeposit(feesCalculator, mockDbHandler);
        TransactionData transactionData = new TransactionData(cardNum, pin, TransactionType.Deposit, accounts, amount);
        TransactionResult transactionResult = bankDeposit.perform(transactionData);

        assertEquals(result, transactionResult.getFees());
    }

    // TEST FOR NO STUBS
    @ParameterizedTest
    @MethodSource("testParams")
    void bankDepositTest3(double result, double amount, double accountBalance, boolean student) throws Exception {
        String username = student ? STUDENT_CARD_OWNER : NON_STUDENT_CARD_OWNER;
        String cardNum = student ? STUDENT_CARD_NUMBER : NON_STUDENT_CARD_NUMBER;
        char[] pin = student ? STUDENT_PIN : NON_STUDENT_PIN;

        dbHandler.setBalance(username, AccountType.Chequing, accountBalance);

        BankDeposit bankDeposit = new BankDeposit(feesCalculator, dbHandler);
        TransactionData transactionData = new TransactionData(cardNum, pin, TransactionType.Deposit, accounts, amount);
        TransactionResult transactionResult = bankDeposit.perform(transactionData);

        assertEquals(result, transactionResult.getFees());
    }
}
