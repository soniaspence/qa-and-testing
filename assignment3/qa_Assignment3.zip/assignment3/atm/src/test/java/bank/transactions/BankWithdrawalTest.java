package bank.transactions;

import bank.db.DBHandler;
import bank.transactions.utils.AccountType;
import bank.transactions.utils.TransactionData;
import bank.transactions.utils.TransactionResult;
import bank.transactions.utils.TransactionType;
import bank.utils.FeesCalculator;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class BankWithdrawalTest {
    private static final String STUDENT_CARD_NUMBER = "4000000000000000";
    private static final String STUDENT_CARD_OWNER = "ktsiounis";
    private static final String NON_STUDENT_CARD_NUMBER = "4000000000000001";
    private static final String NON_STUDENT_CARD_OWNER = "khu";
    private static final char[] STUDENT_PIN = "5555".toCharArray();
    private static final char[] NON_STUDENT_PIN = "4444".toCharArray();
    public AccountType[] accounts = {AccountType.Chequing, AccountType.Savings};

    public FeesCalculator mockFeesCalculator;
    public DBHandler mockDbHandler;

    public FeesCalculator feesCalculator;
    public DBHandler dbHandler;

    private static Stream<Arguments> testParams() {
        return Stream.of(
                Arguments.of(0, 500, 1000, true, 1),
                Arguments.of(0.10, 100, 1000, true, 3),
                Arguments.of(0.50, 250, 500, false, 3),
                Arguments.of(1, 1000, 5000, false, 3),
                Arguments.of(0, 5000, 20000, false, 3)
        );
    }

    @BeforeAll
    void setUp(){
        mockFeesCalculator = mock(FeesCalculator.class);
        mockDbHandler = mock(DBHandler.class);

        feesCalculator = new FeesCalculator();
        dbHandler = new DBHandler();
    }

    // 2 stubs
    @ParameterizedTest
    @MethodSource("testParams")
    void bankDepositTest1(double result, double amount, double accountBalance, boolean student, int dayOfWeek) throws Exception {
        String username = student ? STUDENT_CARD_OWNER : NON_STUDENT_CARD_OWNER;
        String cardNum = student ? STUDENT_CARD_NUMBER : NON_STUDENT_CARD_NUMBER;
        char[] pin = student ? STUDENT_PIN : NON_STUDENT_PIN;
        
        when(mockDbHandler.getCardOwner(cardNum)).thenReturn(username);
        when(mockDbHandler.getBalance(username, AccountType.Chequing)).thenReturn(accountBalance);
        when(mockDbHandler.isStudent(username)).thenReturn(student);
        when(mockFeesCalculator.calculateWithdrawalFee(amount, accountBalance, student, dayOfWeek)).thenReturn(result);

        BankWithdrawal bankWithdrawal = new BankWithdrawal(mockFeesCalculator, mockDbHandler);
        TransactionData transactionData = new TransactionData(cardNum, pin, TransactionType.Withdrawal, accounts, amount, dayOfWeek);
        TransactionResult transactionResult = bankWithdrawal.perform(transactionData);

        assertEquals(result, transactionResult.getFees());
    }

    // 1 stub
    @ParameterizedTest
    @MethodSource("testParams")
    void bankDepositTest2(double result, double amount, double accountBalance, boolean student, int dayOfWeek) throws Exception {
        String username = student ? STUDENT_CARD_OWNER : NON_STUDENT_CARD_OWNER;
        String cardNum = student ? STUDENT_CARD_NUMBER : NON_STUDENT_CARD_NUMBER;
        char[] pin = student ? STUDENT_PIN : NON_STUDENT_PIN;

        when(mockDbHandler.getCardOwner(cardNum)).thenReturn(username);
        when(mockDbHandler.isStudent(username)).thenReturn(student);
        when(mockDbHandler.getBalance(username, AccountType.Chequing)).thenReturn(accountBalance);


        BankWithdrawal bankWithdrawal = new BankWithdrawal(feesCalculator, mockDbHandler);
        TransactionData transactionData = new TransactionData(cardNum, pin, TransactionType.Withdrawal, accounts, amount, dayOfWeek);
        TransactionResult transactionResult = bankWithdrawal.perform(transactionData);

        assertEquals(result, transactionResult.getFees());
    }

    // 0 stubs
    @ParameterizedTest
    @MethodSource("testParams")
    void bankDepositTest3(double result, double amount, double accountBalance, boolean student, int dayOfWeek) throws Exception {
        String username = student ? STUDENT_CARD_OWNER : NON_STUDENT_CARD_OWNER;
        String cardNum = student ? STUDENT_CARD_NUMBER : NON_STUDENT_CARD_NUMBER;
        char[] pin = student ? STUDENT_PIN : NON_STUDENT_PIN;

        dbHandler.setBalance(username, AccountType.Chequing, accountBalance);
        
        BankWithdrawal bankWithdrawal = new BankWithdrawal(feesCalculator, dbHandler);
        TransactionData transactionData = new TransactionData(cardNum, pin, TransactionType.Withdrawal, accounts, amount, dayOfWeek);
        TransactionResult transactionResult = bankWithdrawal.perform(transactionData);

        assertEquals(result, transactionResult.getFees());
    }
}
