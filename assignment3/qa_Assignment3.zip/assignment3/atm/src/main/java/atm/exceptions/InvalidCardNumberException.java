package atm.exceptions;

public class InvalidCardNumberException extends Exception {

}
