package bank.exceptions;

public class WrongOperationException extends Exception {

}
