/**
 * 250 970 384
 * Sonia Spence
 * CS 3372 Assignment 2
 * FeesCalculatorDepositTest.java
 * 
 */
package bank.utils;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;



	// Use of Parameterized helps in this case, since multiple runs of same test are required
class FeesCalculatorDepositTest {
		FeesCalculator calculator = new FeesCalculator();

		@BeforeEach
		void setUp() throws Exception {
		}

		@AfterEach
		void tearDown() throws Exception {
		}

		@Test
		void depositTest() {
			//assertEquals(2, calculator.calculateDepositInterest(200, 1100, true));		//pass
			//assertEquals(1, calculator.calculateDepositInterest(200, 500, true));			//pass
			//assertEquals(0.25, calculator.calculateDepositInterest(50, 5500, true));		//pass
			//assertEquals(0, calculator.calculateDepositInterest(50, 2500, true));			//fail
			//assertEquals(5.5, calculator.calculateDepositInterest(550, 5500, false));		//pass
			//assertEquals(2.75, calculator.calculateDepositInterest(550, 2500, false));	//pass
			//assertEquals(1.25, calculator.calculateDepositInterest(250, 11000, false));	//pass
			//assertEquals(0, calculator.calculateDepositInterest(250, 9000, false));		//pass
		}

	}