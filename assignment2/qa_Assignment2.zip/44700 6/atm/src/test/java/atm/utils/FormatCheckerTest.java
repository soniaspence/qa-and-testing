package atm.utils;

import atm.exceptions.InvalidCardNumberException;
import atm.exceptions.InvalidPinFormatException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;


public class FormatCheckerTest {

    // Use of Parameterized helps in this case, since multiple runs of same test are required

    FormatChecker checker = new FormatChecker();

    @BeforeEach
    void setUp() throws Exception {
    }

    @AfterEach
    void tearDown() throws Exception {
    }


    @Test
    void cardCheck() {

        //Visa
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("456712345678"));
        assertDoesNotThrow(()-> checker.checkCardFormat("4567123456789"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("45671234567899"));
        assertDoesNotThrow(()-> checker.checkCardFormat("4567123456789999"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("456712345678999988"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("4567123456789999887"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("45671234567899998876"));


        //MasterCard
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("513456712567987"));
        assertDoesNotThrow(()-> checker.checkCardFormat("5134567125679872"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("51345671256798726"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("523456712567987"));
        assertDoesNotThrow(()-> checker.checkCardFormat("5234567125679872"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("52345671256798726"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("533456712567987"));
        assertDoesNotThrow(()-> checker.checkCardFormat("5334567125679872"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("53345671256798726"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("543456712567987"));
        assertDoesNotThrow(()-> checker.checkCardFormat("5434567125679872"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("54345671256798726"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("553456712567987"));
        assertDoesNotThrow(()-> checker.checkCardFormat("5534567125679872"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("55345671256798726"));



        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("601126789534523"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6011267895345237"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("60112678953452377"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6011267895345238853"));

        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("644129876523456"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6441298765234562"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("64412987652345627"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6441298765234562789"));

        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("645129876523456"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6451298765234562"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("64512987652345627"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6451298765234562789"));

        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("646129876523456"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6461298765234562"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("64612987652345627"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6461298765234562789"));

        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("647129876523456"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6471298765234562"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("64712987652345627"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6471298765234562789"));

        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("648129876523456"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6481298765234562"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("64812987652345627"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6481298765234562789"));

        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("649129876523456"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6491298765234562"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("64912987652345627"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6491298765234562789"));

        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("657129876523456"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6571298765234562"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("65712987652345627"));
        assertDoesNotThrow(()-> checker.checkCardFormat("6571298765234562789"));

        //Amex
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("34516789324567"));
        assertDoesNotThrow(()-> checker.checkCardFormat("345167893245679"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("3451678932456796"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("37516789324567"));
        assertDoesNotThrow(()-> checker.checkCardFormat("375167893245679"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("3751678932456796"));

        //Diners
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("3001478643896"));
        assertDoesNotThrow(()-> checker.checkCardFormat("30014786438962"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("300147864389632"));

        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("3011478643896"));
        assertDoesNotThrow(()-> checker.checkCardFormat("30114786438962"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("301147864389632"));

        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("3021478643896"));
        assertDoesNotThrow(()-> checker.checkCardFormat("30214786438962"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("302147864389632"));

        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("3031478643896"));
        assertDoesNotThrow(()-> checker.checkCardFormat("30314786438962"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("303147864389632"));

        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("3041478643896"));
        assertDoesNotThrow(()-> checker.checkCardFormat("30414786438962"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("304147864389632"));

        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("3051478643896"));
        assertDoesNotThrow(()-> checker.checkCardFormat("30514786438962"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("305147864389632"));

        //JCB
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("352819876523456"));
        assertDoesNotThrow(()-> checker.checkCardFormat("3528198765234562"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("35281987652345621"));
        assertDoesNotThrow(()-> checker.checkCardFormat("3528198765234567654"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("35281987652345664318"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("352919876523456"));
        assertDoesNotThrow(()-> checker.checkCardFormat("3529198765234562"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("35291987652345621"));
        assertDoesNotThrow(()-> checker.checkCardFormat("3529198765234567654"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("35291987652345664318"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("355519876523456"));
        assertDoesNotThrow(()-> checker.checkCardFormat("3555198765234562"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("35551987652345621"));
        assertDoesNotThrow(()-> checker.checkCardFormat("3555198765234567654"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("35551987652345664318"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("358819876523456"));
        assertDoesNotThrow(()-> checker.checkCardFormat("3588198765234562"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("35881987652345621"));
        assertDoesNotThrow(()-> checker.checkCardFormat("3588198765234567654"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("35881987652345664318"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("358919876523456"));
        assertDoesNotThrow(()-> checker.checkCardFormat("3589198765234562"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("35891987652345621"));
        assertDoesNotThrow(()-> checker.checkCardFormat("3589198765234567654"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("35891987652345664318"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("359019876523456"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("3590198765234562"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("35901987652345621"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("3590198765234567654"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("35901987652345664318"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("352719876523456"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("3527198765234562"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("35271987652345621"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("3527198765234567654"));
        assertThrows(InvalidCardNumberException.class, ()-> checker.checkCardFormat("35271987652345664318"));
    }

    @Test
    void pinCheck() {

        //length
        char[] pin = {'1', '2', '3'};
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));

        char[] pin2 = {'1', '2', '3', '4'};
        assertDoesNotThrow(()-> checker.checkPinFormat(pin));

        char[] pin3 = {'1', '2', '3', '4', '5'};
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));


        //digits
        char[] digits = {'/', '4', '4', '4'};
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));
        digits[0] = ':';
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));

        char[] digits2 = {'4', '/', '4', '4'};
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));
        digits[1] = ':';
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));

        char[] digits3 = {'4', '4', '/', '4'};
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));
        digits[2] = ':';
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));

        char[] digits4 = {'4', '4', '4', '/'};
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));
        digits[3] = ':';
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));

        char[] digits5 = {'4', '4', '4', '/'};
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));
        digits[3] = ':';
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));

        char[] digits6 = {'/', ':', '4', '4'};
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));
        digits[0] = ':';
        digits[1] = '/';
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));

        char[] digits7 = {'/', '4', ':', '4'};
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));
        digits[0] = ':';
        digits[2] = '/';
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));

        char[] digits8 = {'/', '4', '4', ':'};
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));
        digits[0] = ':';
        digits[3] = '/';
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));

        char[] digits9 = {'4', '/', ':', '4'};
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));
        digits[1] = ':';
        digits[2] = '/';
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));

        char[] digits10 = {'4', '4', '/', ':'};
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));
        digits[2] = ':';
        digits[3] = '/';
        assertThrows(InvalidPinFormatException.class, ()-> checker.checkPinFormat(pin));

        char[] valid = {'4', '4', '4', '4'};
        assertDoesNotThrow(()-> checker.checkPinFormat(pin));

    }


}