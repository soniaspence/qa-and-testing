package atm;

import atm.utils.CashValidator;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

// Use of Parameterized helps in this case, since multiple runs of same test are required
class CashValidatorTestWithdrawal {

    CashValidator validator = new CashValidator();

    @BeforeEach
    void setUp() throws Exception {
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    @SuppressWarnings("static-access")
    @Test
    void withdrawalTest() {
        assertEquals(true, validator.validateWithdrawal(20));		//pass
        assertEquals(true, validator.validateWithdrawal(50));		//pass
        assertEquals(false, validator.validateWithdrawal(15));	//pass
        assertEquals(false, validator.validateWithdrawal(25));		//pass

    }

}