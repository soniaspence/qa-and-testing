package atm.exceptions;

public class InvalidCredentialsException extends Exception {

}
