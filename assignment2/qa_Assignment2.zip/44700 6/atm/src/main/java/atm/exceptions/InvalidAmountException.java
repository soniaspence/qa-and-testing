package atm.exceptions;

public class InvalidAmountException extends Exception {

}
