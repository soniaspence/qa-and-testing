package bank.exceptions;

public class CardNotFoundException extends Exception {

}
